import React, { Component } from 'react'
import { View } from 'react-native'

class PPOBItem extends Component{
  constructor(props: any){
    super(props)
  }
  render = () => 
    <View>

    </View>
}

export default PPOBItem