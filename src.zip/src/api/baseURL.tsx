const baseURL = 'https://borneopoint.co.id/public'
// const baseURL = 'http://192.168.1.236:3333'


export default baseURL